from pylack_ import main

print("testing main module...")
main.root()
