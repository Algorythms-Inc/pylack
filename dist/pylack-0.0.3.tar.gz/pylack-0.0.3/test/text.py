from docx import Document

docx_filename = "reports.docx"
doc = Document()
doc.save(docx_filename)
